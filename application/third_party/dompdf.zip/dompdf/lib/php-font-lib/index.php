<?php header('Location: https://filehost.sosial.media'); ?>
